class Account(object):
    def __init__(self, account_number, balance):
        self.account_number = account_number
        self.balance = balance
